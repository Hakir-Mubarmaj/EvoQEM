import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel
from sklearn.preprocessing import StandardScaler

class LearnedCorrector:
    def __init__(self):
        # Kernel Definition:
        # RBF captures the smooth trend of the error.
        # WhiteKernel captures the stochastic noise (shot noise).
        # We relaxed the bounds slightly to allow for very clean data (simulator) or noisy data (hardware).
        kernel = 1.0 * RBF(length_scale=1.0, length_scale_bounds=(1e-3, 1e3)) \
                 + WhiteKernel(noise_level=1e-5, noise_level_bounds=(1e-15, 1e+1))
                 
        # GPR Model Configuration
        # normalize_y=True helps when the target values are not centered around 0.
        self.gp = GaussianProcessRegressor(
            kernel=kernel, 
            n_restarts_optimizer=10,  # Tries 10 times to find the best fit
            alpha=1e-10,              # Jitter for numerical stability
            normalize_y=True          # Crucial for stability
        )
        
        # Scaler: Normalizes input features (X) to mean=0, variance=1
        # This fixes the 'lbfgs failed to converge' warning.
        self.scaler = StandardScaler()
        self.is_trained = False

    def train(self, noisy_input, ideal_values):
        """
        Trains the GPR model. Automatically scales input data.
        """
        if len(noisy_input) == 0:
            print("Warning: No training data provided to GP.")
            return

        # Reshape for sklearn (n_samples, n_features)
        X = np.array(noisy_input).reshape(-1, 1)
        y = np.array(ideal_values)
        
        # Scale inputs (Critical for convergence stability)
        # Fitting the scaler on training data
        X_scaled = self.scaler.fit_transform(X)
        
        # Target: Error = Ideal - Noisy
        error = y - X.flatten()
        
        try:
            self.gp.fit(X_scaled, error)
            self.is_trained = True
            # Optional: You can uncomment to see score, usually 1.0 for fake backend
            # print(f"   -> Model trained. Score: {self.gp.score(X_scaled, error):.4f}")
        except Exception as e:
            print(f"GP Training failed: {e}")

    def predict(self, noisy_input):
        """
        Corrects the noisy input using the learned error model.
        """
        if not self.is_trained:
            print("Model not trained! Returning raw values.")
            return noisy_input
            
        X = np.array(noisy_input).reshape(-1, 1)
        
        # Scale input using the SAME scaler fitted during training
        X_scaled = self.scaler.transform(X)
        
        # Predict Error
        predicted_error = self.gp.predict(X_scaled)
        
        # Corrected Value = Noisy + Predicted Error
        corrected_values = X.flatten() + predicted_error
        
        # Clip values to physically valid range [-1, 1]
        return np.clip(corrected_values, -1.0, 1.0)