import numpy as np
from qiskit.quantum_info import Statevector
from qiskit.circuit import Parameter

def generate_calibration_circuits(base_subcircuits, num_samples=20):
    """
    Smart Calibration: Modifies EXISTING angles instead of adding new gates.
    This preserves the circuit structure and prevents SWAP explosion during transpilation.
    
    Args:
        base_subcircuits (list): List containing the base circuit to perturb.
        num_samples (int): Number of training samples to generate.
        
    Returns:
        tuple: (training_circuits, ideal_values)
    """
    training_circuits = []
    ideal_values = []
    
    # We take the first subcircuit as the template
    target_qc = base_subcircuits[0] 
    
    print(f"Generating {num_samples} smart calibration variants...")
    
    for _ in range(num_samples):
        # 1. Copy the circuit
        cal_qc = target_qc.copy()
        
        # 2. Perturb parameters while keeping structure
        param_shifted = False
        
        for instruction in cal_qc.data:
            # instruction is a CircuitInstruction object
            op = instruction.operation
            
            # Check if the gate has parameters (angles)
            if hasattr(op, 'params') and len(op.params) > 0:
                new_params = []
                for p in op.params:
                    if isinstance(p, float):
                        # Shift angle by uniform noise [-0.5, +0.5] radians
                        shift = np.random.uniform(-0.5, 0.5)
                        new_params.append(p + shift)
                        param_shifted = True
                    else:
                        new_params.append(p)
                
                # Update parameters
                op.params = new_params

        # Fallback: if no parameters found (e.g., only H, CNOT), add a dummy rotation
        if not param_shifted:
            cal_qc.rx(np.random.uniform(0.1, 0.5), 0)
        
        training_circuits.append(cal_qc)
        
        # 3. Calculate Ideal Expectation Value (<ZZ>) for this perturbed circuit
        # We calculate <Z0 * Z1> (assuming 2 qubits per fragment)
        psi = Statevector.from_instruction(cal_qc)
        
        # Calculate Expectation of ZZ (Pauli Z on qubit 0 and Z on qubit 1)
        from qiskit.quantum_info import Pauli
        op = Pauli('Z' * cal_qc.num_qubits) # Dynamically match qubit count
        ideal_val = psi.expectation_value(op).real
        
        ideal_values.append(ideal_val)
        
    return training_circuits, ideal_values