# src/executor.py (Fixed: Added measurements before execution)
from qiskit_ibm_runtime.fake_provider import FakeSherbrooke, FakeFez
from qiskit import transpile

class VirtualExecutor:
    def __init__(self, backend_name='fez'):
        if backend_name == 'fez':
            self.backend = FakeFez()
        else:
            self.backend = FakeSherbrooke()
        
        print(f"Executor initialized with: {self.backend.name}")

    def run_mitigation_experiments(self, circuits, shots=4000):
        """
        Runs circuits on the noisy backend and calculates raw expectation values.
        Automatically adds measurements to the circuits if missing.
        
        Args:
            circuits (list): List of QuantumCircuits (without measurements usually).
            shots (int): Number of shots.
            
        Returns:
            list: List of noisy expectation values <ZZ..Z>.
        """
        
        # 1. Add Measurements explicitly
        # We need to measure all qubits to calculate <ZZ...Z> expectation.
        circuits_with_meas = []
        for qc in circuits:
            # measure_all(inplace=False) creates a new circuit with measurement gates
            # This leaves the original 'qc' clean (important for logic elsewhere)
            qc_meas = qc.measure_all(inplace=False)
            circuits_with_meas.append(qc_meas)

        print(f"Transpiling {len(circuits_with_meas)} circuits with optimization...")
        
        # 2. Transpile the circuits containing measurements
        # Optimization Level 3 and SABRE layout to minimize noise impact
        transpiled_circuits = transpile(
            circuits_with_meas, 
            self.backend, 
            optimization_level=3, 
            layout_method='sabre'
        )
        
        # 3. Run job
        job = self.backend.run(transpiled_circuits, shots=shots)
        result = job.result()
        
        expvals = []
        for i in range(len(circuits)):
            try:
                counts = result.get_counts(i)
            except Exception as e:
                print(f"Error getting counts for circuit {i}: {e}")
                expvals.append(0.0) # Fallback
                continue
            
            # Calculate Expectation Value <ZZ...Z> from counts
            # ExpVal = (Count(Even Parity) - Count(Odd Parity)) / Total Shots
            
            val = 0
            total_counts = 0
            
            for state, count in counts.items():
                # state string might look like "00 10" (if multiple registers) -> remove spaces
                cleaned_state = state.replace(" ", "")
                
                # Calculate parity (number of 1s)
                ones = cleaned_state.count('1')
                
                if ones % 2 == 0:
                    val += count  # +1 for even parity (Eigenvalue +1)
                else:
                    val -= count  # -1 for odd parity (Eigenvalue -1)
                total_counts += count
            
            if total_counts > 0:
                expvals.append(val / total_counts)
            else:
                expvals.append(0.0)
            
        return expvals