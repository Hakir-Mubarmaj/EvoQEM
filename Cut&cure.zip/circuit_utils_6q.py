import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, Pauli

def get_target_circuit():
    """
    Creates a larger 6-qubit target circuit for scalability testing.
    Structure: 3 pairs of entangled qubits (0-1, 2-3, 4-5).
    """
    qc = QuantumCircuit(6)
    
    # Apply rotations to all qubits (makes it non-trivial)
    qc.rx(0.5, 0)
    qc.rx(0.6, 1)
    qc.rx(0.7, 2)
    qc.rx(0.8, 3)
    qc.rx(0.9, 4)
    qc.rx(1.0, 5)
    
    # Apply Entangling Gates (CZ)
    # This creates the structure we will cut later
    qc.cz(0, 1)
    qc.cz(2, 3)
    qc.cz(4, 5)
    
    return qc

def get_cut_subcircuits():
    """
    Manually cuts the 6-qubit circuit into 3 independent fragments.
    Each fragment is a 2-qubit circuit.
    """
    # Fragment 1 (Original Qubits 0, 1)
    qc1 = QuantumCircuit(2)
    qc1.rx(0.5, 0)
    qc1.rx(0.6, 1)
    qc1.cz(0, 1)
    
    # Fragment 2 (Original Qubits 2, 3 -> Mapped to 0, 1)
    qc2 = QuantumCircuit(2)
    qc2.rx(0.7, 0)
    qc2.rx(0.8, 1)
    qc2.cz(0, 1)
    
    # Fragment 3 (Original Qubits 4, 5 -> Mapped to 0, 1)
    qc3 = QuantumCircuit(2)
    qc3.rx(0.9, 0)
    qc3.rx(1.0, 1)
    qc3.cz(0, 1)
    
    return [qc1, qc2, qc3]

def get_true_ideal_value():
    """
    Calculates the exact theoretical expectation value for the full 6-qubit circuit.
    Measuring operator: <Z0 Z1 Z2 Z3 Z4 Z5>
    """
    qc = get_target_circuit()
    psi = Statevector.from_instruction(qc)
    
    # Expectation of Z tensor product 6 times
    op = Pauli('Z' * 6)
    return psi.expectation_value(op).real

def ideal_reconstruction(sub_results):
    """
    Reconstructs the global expectation value from sub-circuit results.
    Since the cuts are independent (tensor product), we multiply the results.
    
    Args:
        sub_results (list): List of expectation values from the 3 fragments.
    """
    final_val = 1.0
    for val in sub_results:
        final_val *= val
    return final_val